﻿using YahtzeeProject;
using YahtzeeProject.Models;

static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        if (args.Contains("--train"))
        {
            // Rulează antrenamentul algoritmului Q-learning
            var gameState = new GameState();
            var qLearning = new QLearning();

            // Acțiuni posibile (păstrarea unor zaruri)
            var possibleActions = new List<string>
{
    "0", "1", "2", "3", "4",
    "0,1", "0,2", "0,3", "0,4",
    "1,2", "1,3", "1,4",
    "2,3", "2,4",
    "3,4",
    "0,1,2", "0,1,3", "0,1,4",
    "0,2,3", "0,2,4",
    "0,3,4",
    "1,2,3", "1,2,4",
    "1,3,4",
    "2,3,4",
    "0,1,2,3", "0,1,2,4",
    "0,1,3,4",
    "0,2,3,4",
    "1,2,3,4",
    "0,1,2,3,4",
    "ChooseOnes",
    "ChooseTwos",
    "ChooseThrees",
    "ChooseFours",
    "ChooseFives",
    "ChooseSixes",
    "ChooseThreeOfAKind",
    "ChooseFourOfAKind",
    "ChooseFullHouse",
    "ChooseSmallStraight",
    "ChooseLargeStraight",
    "ChooseYahtzee",
    "ChooseChance"
};


            // Antrenare pe mai multe episoade
            int episodes = 20000; // Numărul de episoade (ajustează pentru performanță mai bună)
            var rewards = qLearning.Train(gameState, possibleActions, episodes);

            // Afișează graficul de convergență
            qLearning.DisplayConvergenceChart(rewards);

            // Salvează tabela Q după antrenament
            qLearning.SaveQTable("QTable.json");

            // Afișează politica determinată de algoritmul Q-learning
            qLearning.DisplayPolicy();
        }
        else
        {
            // Pornește jocul grafic
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new GameForm());
        }
    }
}
//YahtzeeGame_Project.exe --train | more
//YahtzeeGame_Project.exe --train > politica.txt