﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using YahtzeeProject.Models;

namespace YahtzeeProject
{
    public partial class GameForm : Form
    {
        private YahtzeeGame game;
        private List<CheckBox> diceCheckBoxes = new List<CheckBox>();
        private Random random = new Random();

        public GameForm()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void UpdateCategoryComboBox()
        {
            comboBoxCategory.Items.Clear(); // Golim lista anterioară
            foreach (var category in game.GameState.UserScoreCard.Keys)
            {
                if (game.GameState.IsCategoryAvailable(category))
                {
                    comboBoxCategory.Items.Add(category);
                }
            }
            comboBoxCategory.SelectedIndex = -1; // Resetăm selecția
        }

        private void InitializeGame()
        {
            game = new YahtzeeGame();
            diceCheckBoxes.AddRange(new[] { checkBoxDice1, checkBoxDice2, checkBoxDice3, checkBoxDice4, checkBoxDice5 });
            UpdateDiceDisplay();
            InitializeScoreCardGrids();
            UpdateScoreCardDisplays();
            // Popularează comboBox-ul cu categoriile disponibile
            comboBoxCategory.Items.Clear();
            comboBoxCategory.Items.AddRange(game.GameState.UserScoreCard.Keys.ToArray());
            buttonChooseCategory.Enabled = false; // Dezactivăm butonul de alegere a categoriei la începutul jocului
        }

        // Funcție pentru inițializarea tabelelor de scor
        private void InitializeScoreCardGrids()
        {
            userScoreCardGrid.Columns.Clear();
            userScoreCardGrid.Columns.Add("Category", "Category");
            userScoreCardGrid.Columns.Add("UserScore", "User Score");
            aiScoreCardGrid.Columns.Clear();
            aiScoreCardGrid.Columns.Add("Category", "Category");
            aiScoreCardGrid.Columns.Add("AIScore", "AI Score");
        }

        // Funcție pentru afișarea zarurilor
        private void UpdateDiceDisplay()
        {
            for (int i = 0; i < game.GameState.Dice.Length; i++)
            {
                diceCheckBoxes[i].Text = game.GameState.Dice[i].ToString();
                diceCheckBoxes[i].Checked = false; // Debifăm toate zarurile
            }
        }

        // Funcție pentru actualizarea tabelelor de scor
        private void UpdateScoreCardDisplays()
        {
            userScoreCardGrid.Rows.Clear();
            aiScoreCardGrid.Rows.Clear();
            foreach (var entry in game.GameState.UserScoreCard)
            {
                userScoreCardGrid.Rows.Add(entry.Key, entry.Value?.ToString() ?? "N/A");
            }
            foreach (var entry in game.GameState.AIScoreCard)
            {
                aiScoreCardGrid.Rows.Add(entry.Key, entry.Value?.ToString() ?? "N/A");
            }
        }

        // Funcția pentru butonul de aruncare zaruri
        private void buttonRollDice_Click(object sender, EventArgs e)
        {
            if (game.GameState.RollsRemaining > 0)
            {
                int[] diceToKeep = diceCheckBoxes
                    .Select((cb, index) => cb.Checked ? index : -1)
                    .Where(index => index != -1)
                    .ToArray();

                game.RollDice(diceToKeep);
                UpdateDiceDisplay();
                buttonChooseCategory.Enabled = true; // Activăm butonul de alegere a categoriei după prima aruncare
                if (game.GameState.RollsRemaining == 0)
                {
                    buttonRollDice.Enabled = false; // Dezactivăm butonul de aruncare a zarurilor dacă nu mai avem aruncări
                }
            }
        }

        // Funcția pentru alegerea categoriei de scor de către jucător
        private void buttonChooseCategory_Click(object sender, EventArgs e)
        {
            string selectedCategory = comboBoxCategory.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedCategory) && game.GameState.IsCategoryAvailable(selectedCategory))
            {
                game.UpdateScore(selectedCategory);
                UpdateScoreCardDisplays();
                comboBoxCategory.Items.Remove(selectedCategory); // Eliminăm elementul selectat din comboBoxCategory
                comboBoxCategory.SelectedIndex = -1; // Resetăm selecția din comboBoxCategory
                buttonChooseCategory.Enabled = false;
                buttonRollDice.Enabled = true;
                // După turul jucătorului, AI-ul joacă
                MessageBox.Show("AI is taking its turn...");
                AITurn();
            }
            else
            {
                MessageBox.Show("Please select a valid category.");
            }
        }

        // Funcția pentru turul AI-ului
        private void AITurn()
        {
            game.AITurn();
            UpdateScoreCardDisplays();
            UpdateDiceDisplay(); // Actualizăm afișarea zarurilor după turul AI-ului
            if (game.GameState.IsGameOver())
            {
                int userTotalScore = game.GameState.GetTotalScore(game.GameState.UserScoreCard);
                int aiTotalScore = game.GameState.GetTotalScore(game.GameState.AIScoreCard);
                string winner = userTotalScore > aiTotalScore ? "User" : "AI";
                MessageBox.Show($"Game over! {winner} wins with a score of {Math.Max(userTotalScore, aiTotalScore)}!");
                InitializeGame();
            }
        }

        private void InitializeComponent()
        {
            userScoreCardGrid = new DataGridView();
            aiScoreCardGrid = new DataGridView();
            checkBoxDice1 = new CheckBox();
            checkBoxDice2 = new CheckBox();
            checkBoxDice3 = new CheckBox();
            checkBoxDice4 = new CheckBox();
            checkBoxDice5 = new CheckBox();
            buttonRollDice = new Button();
            buttonChooseCategory = new Button();
            comboBoxCategory = new ComboBox();
            labelUser = new Label();
            labelAI = new Label();
            ((System.ComponentModel.ISupportInitialize)userScoreCardGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)aiScoreCardGrid).BeginInit();
            SuspendLayout();
            // 
            // userScoreCardGrid
            // 
            userScoreCardGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            userScoreCardGrid.Location = new Point(14, 43);
            userScoreCardGrid.Margin = new Padding(3, 4, 3, 4);
            userScoreCardGrid.Name = "userScoreCardGrid";
            userScoreCardGrid.RowHeadersWidth = 51;
            userScoreCardGrid.Size = new Size(274, 200);
            userScoreCardGrid.TabIndex = 0;
            // 
            // aiScoreCardGrid
            // 
            aiScoreCardGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            aiScoreCardGrid.Location = new Point(323, 43);
            aiScoreCardGrid.Margin = new Padding(3, 4, 3, 4);
            aiScoreCardGrid.Name = "aiScoreCardGrid";
            aiScoreCardGrid.RowHeadersWidth = 51;
            aiScoreCardGrid.Size = new Size(274, 200);
            aiScoreCardGrid.TabIndex = 1;
            // 
            // checkBoxDice1
            // 
            checkBoxDice1.AutoSize = true;
            checkBoxDice1.Location = new Point(14, 267);
            checkBoxDice1.Margin = new Padding(3, 4, 3, 4);
            checkBoxDice1.Name = "checkBoxDice1";
            checkBoxDice1.Size = new Size(65, 24);
            checkBoxDice1.TabIndex = 2;
            checkBoxDice1.Text = "Zar 1";
            checkBoxDice1.UseVisualStyleBackColor = true;
            // 
            // checkBoxDice2
            // 
            checkBoxDice2.AutoSize = true;
            checkBoxDice2.Location = new Point(14, 300);
            checkBoxDice2.Margin = new Padding(3, 4, 3, 4);
            checkBoxDice2.Name = "checkBoxDice2";
            checkBoxDice2.Size = new Size(65, 24);
            checkBoxDice2.TabIndex = 3;
            checkBoxDice2.Text = "Zar 2";
            checkBoxDice2.UseVisualStyleBackColor = true;
            // 
            // checkBoxDice3
            // 
            checkBoxDice3.AutoSize = true;
            checkBoxDice3.Location = new Point(14, 333);
            checkBoxDice3.Margin = new Padding(3, 4, 3, 4);
            checkBoxDice3.Name = "checkBoxDice3";
            checkBoxDice3.Size = new Size(65, 24);
            checkBoxDice3.TabIndex = 4;
            checkBoxDice3.Text = "Zar 3";
            checkBoxDice3.UseVisualStyleBackColor = true;
            // 
            // checkBoxDice4
            // 
            checkBoxDice4.AutoSize = true;
            checkBoxDice4.Location = new Point(14, 367);
            checkBoxDice4.Margin = new Padding(3, 4, 3, 4);
            checkBoxDice4.Name = "checkBoxDice4";
            checkBoxDice4.Size = new Size(65, 24);
            checkBoxDice4.TabIndex = 5;
            checkBoxDice4.Text = "Zar 4";
            checkBoxDice4.UseVisualStyleBackColor = true;
            // 
            // checkBoxDice5
            // 
            checkBoxDice5.AutoSize = true;
            checkBoxDice5.Location = new Point(14, 400);
            checkBoxDice5.Margin = new Padding(3, 4, 3, 4);
            checkBoxDice5.Name = "checkBoxDice5";
            checkBoxDice5.Size = new Size(65, 24);
            checkBoxDice5.TabIndex = 6;
            checkBoxDice5.Text = "Zar 5";
            checkBoxDice5.UseVisualStyleBackColor = true;
            // 
            // buttonRollDice
            // 
            buttonRollDice.Location = new Point(114, 267);
            buttonRollDice.Margin = new Padding(3, 4, 3, 4);
            buttonRollDice.Name = "buttonRollDice";
            buttonRollDice.Size = new Size(86, 31);
            buttonRollDice.TabIndex = 7;
            buttonRollDice.Text = "Aruncă Zarurile";
            buttonRollDice.UseVisualStyleBackColor = true;
            buttonRollDice.Click += buttonRollDice_Click;
            // 
            // buttonChooseCategory
            // 
            buttonChooseCategory.Location = new Point(114, 320);
            buttonChooseCategory.Margin = new Padding(3, 4, 3, 4);
            buttonChooseCategory.Name = "buttonChooseCategory";
            buttonChooseCategory.Size = new Size(86, 31);
            buttonChooseCategory.TabIndex = 8;
            buttonChooseCategory.Text = "Alege Categorie";
            buttonChooseCategory.UseVisualStyleBackColor = true;
            buttonChooseCategory.Click += buttonChooseCategory_Click;
            // 
            // comboBoxCategory
            // 
            comboBoxCategory.FormattingEnabled = true;
            comboBoxCategory.Location = new Point(114, 360);
            comboBoxCategory.Margin = new Padding(3, 4, 3, 4);
            comboBoxCategory.Name = "comboBoxCategory";
            comboBoxCategory.Size = new Size(138, 28);
            comboBoxCategory.TabIndex = 9;
            // 
            // labelUser
            // 
            labelUser.AutoSize = true;
            labelUser.Location = new Point(14, 16);
            labelUser.Name = "labelUser";
            labelUser.Size = new Size(38, 20);
            labelUser.TabIndex = 10;
            labelUser.Text = "User";
            // 
            // labelAI
            // 
            labelAI.AutoSize = true;
            labelAI.Location = new Point(295, 16);
            labelAI.Name = "labelAI";
            labelAI.Size = new Size(23, 20);
            labelAI.TabIndex = 11;
            labelAI.Text = "AI";
            // 
            // GameForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GreenYellow;
            ClientSize = new Size(686, 533);
            Controls.Add(labelAI);
            Controls.Add(labelUser);
            Controls.Add(comboBoxCategory);
            Controls.Add(buttonChooseCategory);
            Controls.Add(buttonRollDice);
            Controls.Add(checkBoxDice5);
            Controls.Add(checkBoxDice4);
            Controls.Add(checkBoxDice3);
            Controls.Add(checkBoxDice2);
            Controls.Add(checkBoxDice1);
            Controls.Add(aiScoreCardGrid);
            Controls.Add(userScoreCardGrid);
            Margin = new Padding(3, 4, 3, 4);
            Name = "GameForm";
            Text = "Yahtzee";
            ((System.ComponentModel.ISupportInitialize)userScoreCardGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)aiScoreCardGrid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.DataGridView userScoreCardGrid;
        private System.Windows.Forms.DataGridView aiScoreCardGrid;
        private System.Windows.Forms.CheckBox checkBoxDice1;
        private System.Windows.Forms.CheckBox checkBoxDice2;
        private System.Windows.Forms.CheckBox checkBoxDice3;
        private System.Windows.Forms.CheckBox checkBoxDice4;
        private System.Windows.Forms.CheckBox checkBoxDice5;
        private System.Windows.Forms.Button buttonRollDice;
        private System.Windows.Forms.Button buttonChooseCategory;
        private System.Windows.Forms.ComboBox comboBoxCategory;
        private System.Windows.Forms.Label labelUser;
        private System.Windows.Forms.Label labelAI;
    }
}
