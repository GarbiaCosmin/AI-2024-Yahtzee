﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace YahtzeeProject.Models
{
    public class QLearning
    {
        // Tabela Q: cheie = "state|action", valoare = valoarea Q
        private Dictionary<string, double> QTable;

        // Parametrii algoritmului
        private double alpha = 0.2; // Rata de învățare
        private double gamma = 0.99; // Factorul de discount
        private double epsilon = 1.0; // Probabilitatea de explorare
        private double epsilonDecay = 0.9999; // Decăderea pentru epsilon
        private double epsilonMin = 0.05; // Valoare minimă pentru epsilon
        private Random random = new Random();

        // Constructor
        public QLearning()
        {
            QTable = new Dictionary<string, double>();
            LoadQTable("QTable.json"); // Încarcă QTable din fișier, dacă există
        }

        // Inițializarea stării
        public string InitializeState(GameState gameState)
        {
            return $"Dice:{string.Join(",", gameState.Dice)}|Rolls:{gameState.RollsRemaining}";
        }

        // Adaugă o intrare în tabelă dacă nu există deja
        public void AddStateAction(string state, string action)
        {
            string key = $"{state}|{action}";
            if (!QTable.ContainsKey(key))
            {
                QTable[key] = 0.0; // Inițial, toate valorile Q sunt 0
            }
        }

        // Obține cea mai bună acțiune pentru o stare (epsilon-greedy)
        public string GetBestAction(string state, List<string> possibleActions)
        {
            if (random.NextDouble() < epsilon) // Explorare
            {
                return possibleActions[random.Next(possibleActions.Count)];
            }

            // Exploatare: Alegerea acțiunii cu valoarea Q maximă
            string bestAction = null;
            double maxQ = double.MinValue;

            foreach (var action in possibleActions)
            {
                string key = $"{state}|{action}";
                AddStateAction(state, action);
                double qValue = QTable[key];
                if (qValue > maxQ)
                {
                    maxQ = qValue;
                    bestAction = action;
                }
            }

            return bestAction ?? possibleActions[random.Next(possibleActions.Count)];
        }

        // Obține starea următoare pe baza acțiunii
        public string GetNextState(GameState gameState, string action)
        {
            if (action.StartsWith("Choose"))
            {
                // Acțiunea este de a alege o categorie pentru scor
                string category = action.Replace("Choose", "");
                UpdateScore(gameState, category);
                return InitializeState(gameState);
            }
            else
            {
                // Acțiunea este de păstrare a unor zaruri
                var diceToKeep = action.Split(',').Select(int.Parse).ToArray();

                for (int i = 0; i < gameState.Dice.Length; i++)
                {
                    if (!diceToKeep.Contains(i))
                    {
                        gameState.Dice[i] = random.Next(1, 7);
                    }
                }

                gameState.RollsRemaining--;
                return InitializeState(gameState);
            }
        }

        // Execută un pas Q-learning
        public void QLearningStep(GameState gameState, List<string> possibleActions)
        {
            string currentState = InitializeState(gameState);
            string action = GetBestAction(currentState, possibleActions);
            string nextState = GetNextState(gameState, action);
            string currentKey = $"{currentState}|{action}";

            // Calculare recompensă
            int reward = CalculateReward(gameState);

            // Calculare valoare maximă pentru starea următoare
            double maxNextQ = possibleActions
                .Select(a => QTable.ContainsKey($"{nextState}|{a}") ? QTable[$"{nextState}|{a}"] : 0.0)
                .Max();

            // Actualizare valoare Q
            AddStateAction(currentState, action);
            QTable[currentKey] += alpha * (reward + gamma * maxNextQ - QTable[currentKey]);

            // Reducem epsilon
            UpdateEpsilon();
        }

        // Calcularea recompensei pe baza stării curente
        private int CalculateReward(GameState gameState)
        {
            if (HasNOfAKind(5, gameState.Dice)) return 50; // Yahtzee
            if (IsLargeStraight(gameState.Dice)) return 40;
            if (IsSmallStraight(gameState.Dice)) return 30;
            if (IsFullHouse(gameState.Dice)) return 25;
            return gameState.Dice.Sum(); // Suma zarurilor ca fallback
        }

        // Antrenează algoritmul pe mai multe episoade
        public List<double> Train(GameState gameState, List<string> possibleActions, int episodes)
        {
            List<double> rewardsPerEpisode = new List<double>();

            for (int episode = 1; episode <= episodes; episode++)
            {
                gameState.InitializeGame();
                string currentState = InitializeState(gameState);
                double totalReward = 0;

                while (gameState.RollsRemaining > 0 && !gameState.IsGameOver())
                {
                    QLearningStep(gameState, possibleActions);
                    totalReward += gameState.Dice.Sum();
                }

                rewardsPerEpisode.Add(totalReward);
            }

            return rewardsPerEpisode;
        }

        // Reducerea lui epsilon
        private void UpdateEpsilon()
        {
            epsilon = Math.Max(epsilon * epsilonDecay, epsilonMin);
        }

        // Afișează politica determinată de Q-learning
        public void DisplayPolicy()
        {
            Console.WriteLine("Politica determinată de algoritmul Q-learning:");

            foreach (var entry in QTable.GroupBy(q => q.Key.Split('|')[0]))
            {
                string state = entry.Key;
                string bestAction = entry
                    .OrderByDescending(q => q.Value)
                    .First().Key.Split('|')[1];
                Console.WriteLine($"Stare: {state}, Cea mai bună acțiune: {bestAction}");
            }
        }

        // Salvarea QTable într-un fișier JSON
        public void SaveQTable(string filePath)
        {
            var json = JsonConvert.SerializeObject(QTable, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        // Încărcarea QTable dintr-un fișier JSON
        public void LoadQTable(string filePath)
        {
            if (File.Exists(filePath))
            {
                var json = File.ReadAllText(filePath);
                QTable = JsonConvert.DeserializeObject<Dictionary<string, double>>(json);
            }
        }

        // Funcții auxiliare pentru recompensă
        private bool HasNOfAKind(int n, int[] dice)
        {
            return dice.GroupBy(d => d).Any(g => g.Count() >= n);
        }

        private bool IsFullHouse(int[] dice)
        {
            var grouped = dice.GroupBy(d => d).Select(g => g.Count()).OrderBy(c => c).ToArray();
            return grouped.Length == 2 && grouped[0] == 2 && grouped[1] == 3;
        }

        private bool IsSmallStraight(int[] dice)
        {
            int[] uniqueDice = dice.Distinct().OrderBy(d => d).ToArray();
            return uniqueDice.Contains(1) && uniqueDice.Contains(2) && uniqueDice.Contains(3) && uniqueDice.Contains(4) ||
                   uniqueDice.Contains(2) && uniqueDice.Contains(3) && uniqueDice.Contains(4) && uniqueDice.Contains(5) ||
                   uniqueDice.Contains(3) && uniqueDice.Contains(4) && uniqueDice.Contains(5) && uniqueDice.Contains(6);
        }

        private bool IsLargeStraight(int[] dice)
        {
            int[] uniqueDice = dice.Distinct().OrderBy(d => d).ToArray();
            return uniqueDice.SequenceEqual(new int[] { 1, 2, 3, 4, 5 }) || uniqueDice.SequenceEqual(new int[] { 2, 3, 4, 5, 6 });
        }

        // Actualizarea scorului în funcție de categorie
        private void UpdateScore(GameState gameState, string category)
        {
            int score = 0;
            switch (category)
            {
                case "Ones": score = gameState.Dice.Count(d => d == 1) * 1; break;
                case "Twos": score = gameState.Dice.Count(d => d == 2) * 2; break;
                case "Threes": score = gameState.Dice.Count(d => d == 3) * 3; break;
                case "Fours": score = gameState.Dice.Count(d => d == 4) * 4; break;
                case "Fives": score = gameState.Dice.Count(d => d == 5) * 5; break;
                case "Sixes": score = gameState.Dice.Count(d => d == 6) * 6; break;
                case "ThreeOfAKind": if (HasNOfAKind(3, gameState.Dice)) score = gameState.Dice.Sum(); break;
                case "FourOfAKind": if (HasNOfAKind(4, gameState.Dice)) score = gameState.Dice.Sum(); break;
                case "FullHouse": if (IsFullHouse(gameState.Dice)) score = 25; break;
                case "SmallStraight": if (IsSmallStraight(gameState.Dice)) score = 30; break;
                case "LargeStraight": if (IsLargeStraight(gameState.Dice)) score = 40; break;
                case "Yahtzee": if (HasNOfAKind(5, gameState.Dice)) score = 50; break;
                case "Chance": score = gameState.Dice.Sum(); break;
            }

            if (gameState.IsCategoryAvailable(category))
            {
                if (gameState.CurrentPlayer == "User")
                {
                    gameState.UserScoreCard[category] = score;
                }
                else
                {
                    gameState.AIScoreCard[category] = score;
                }
                gameState.RollsRemaining = 0; // Finaliză turul
            }
        }
        public void DisplayConvergenceChart(List<double> rewardsPerEpisode)
        {
            // Creare formular pentru afișarea graficului
            Form chartForm = new Form
            {
                Text = "Convergența algoritmului Q-learning",
                Size = new Size(800, 600)
            };

            // Configurare PictureBox pentru desenarea graficului
            PictureBox pictureBox = new PictureBox
            {
                Dock = DockStyle.Fill
            };
            chartForm.Controls.Add(pictureBox);

            // Creare imagine bitmap
            Bitmap bitmap = new Bitmap(800, 600);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.Clear(Color.White);

                // Desenare axe
                Pen axisPen = new Pen(Color.Black, 2);
                g.DrawLine(axisPen, 50, 550, 750, 550); // Axa X
                g.DrawLine(axisPen, 50, 550, 50, 50);   // Axa Y

                // Etichete pentru axe
                Font font = new Font("Arial", 10);
                g.DrawString("Episoade", font, Brushes.Black, 700, 560);
                g.DrawString("Recompensă", font, Brushes.Black, 10, 30);

                // Calculare scale
                double maxReward = rewardsPerEpisode.Max();
                int totalEpisodes = rewardsPerEpisode.Count;

                // Desenare curba recompenselor
                Pen linePen = new Pen(Color.Blue, 2);
                for (int i = 0; i < totalEpisodes - 1; i++)
                {
                    float x1 = 50 + (float)(700.0 / totalEpisodes * i);
                    float y1 = 550 - (float)(500.0 / maxReward * rewardsPerEpisode[i]);
                    float x2 = 50 + (float)(700.0 / totalEpisodes * (i + 1));
                    float y2 = 550 - (float)(500.0 / maxReward * rewardsPerEpisode[i + 1]);

                    g.DrawLine(linePen, x1, y1, x2, y2);
                }
            }

            pictureBox.Image = bitmap;
            chartForm.ShowDialog();
        }
    }
}
